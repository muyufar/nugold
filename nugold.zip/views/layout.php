<?php

/**
 * Layout Template Utama
 * Digunakan oleh semua halaman
 */
if (!isset($pageTitle)) {
    $pageTitle = 'Dashboard';
}
$userName = $_SESSION['user_name'] ?? 'User';
$userPhoto = $_SESSION['user_photo'] ?? '';
$isDarkMode = isset($_COOKIE['dark_mode']) && $_COOKIE['dark_mode'] === '1';
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="<?php echo $isDarkMode ? 'dark' : 'light'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Tabungan Emas Digital</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        :root {
            --gold-color: #ffc700;
            --gold-dark: #e6b300;
            --gold-light: #ffd633;
        }

        body {
            background-color: var(--bs-body-bg);
            transition: background-color 0.3s ease;
        }

        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #1a1a1a 0%, #2d2d2d 100%);
            padding: 0;
            position: fixed;
            width: 250px;
            left: 0;
            top: 0;
            z-index: 1000;
            transition: all 0.3s ease;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }

        .sidebar.hidden {
            transform: translateX(-100%);
        }

        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
            cursor: pointer;
            pointer-events: none;
        }

        .sidebar-overlay.show {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
        }

        @media (min-width: 769px) {
            .sidebar-overlay {
                display: none;
            }
        }

        [data-bs-theme="light"] .sidebar {
            background: linear-gradient(180deg, #f8f9fa 0%, #e9ecef 100%);
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar-brand {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 2px solid var(--gold-color);
            background: rgba(255, 199, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .sidebar-brand .d-flex {
            width: 100%;
            align-items: center;
            position: relative;
        }

        .sidebar-brand img {
            flex: 1;
            max-width: calc(100% - 60px);
        }

        #sidebarClose {
            position: absolute;
            right: 0.5rem;
            top: 50%;
            transform: translateY(-50%);
            color: #fff !important;
            opacity: 0.9;
            z-index: 1001;
            cursor: pointer;
            border: none;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        #sidebarClose:hover,
        #sidebarClose:focus,
        #sidebarClose:active {
            opacity: 1;
            outline: none;
            background: rgba(0, 0, 0, 0.4);
            transform: translateY(-50%) scale(1.1);
        }

        [data-bs-theme="light"] #sidebarClose {
            color: #333 !important;
            background: rgba(255, 255, 255, 0.3);
        }

        [data-bs-theme="light"] #sidebarClose:hover,
        [data-bs-theme="light"] #sidebarClose:focus,
        [data-bs-theme="light"] #sidebarClose:active {
            background: rgba(255, 255, 255, 0.5);
        }

        #sidebarClose i {
            pointer-events: none;
            font-size: 1.5rem;
        }

        #sidebarClose.btn-link {
            text-decoration: none;
            padding: 0;
        }

        .sidebar-brand img {
            max-width: 100%;
            height: auto;
            max-height: 120px;
            width: auto;
        }

        .sidebar-brand h4 {
            color: var(--gold-color);
            margin: 0;
            font-weight: bold;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        [data-bs-theme="light"] .sidebar-menu li {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .sidebar-menu a {
            display: block;
            padding: 1rem 1.5rem;
            color: #fff;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        [data-bs-theme="light"] .sidebar-menu a {
            color: #333;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: var(--gold-color);
            color: #000;
            padding-left: 2rem;
        }

        .sidebar-menu a i {
            width: 20px;
            margin-right: 10px;
        }

        .main-content {
            margin-left: 250px;
            padding: 2rem;
            transition: margin-left 0.3s ease;
            min-height: 100vh;
        }

        .main-content.sidebar-hidden {
            margin-left: 0;
        }

        .topbar {
            padding: 1rem 2rem;
            margin: -2rem -2rem 2rem -2rem;
            border-bottom: 1px solid var(--bs-border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(10px);
            background-color: var(--bs-body-bg);
        }

        #sidebarToggle {
            z-index: 101;
            position: relative;
        }

        [data-bs-theme="dark"] .topbar {
            background-color: rgba(26, 26, 26, 0.9);
        }

        [data-bs-theme="light"] .topbar {
            background-color: rgba(255, 255, 255, 0.9);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid var(--gold-color);
        }

        .gold-card {
            background: linear-gradient(135deg, var(--gold-color) 0%, var(--gold-dark) 100%);
            color: #000;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 15px rgba(255, 199, 0, 0.3);
        }

        .stat-card {
            background: var(--bs-card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-left: 4px solid var(--gold-color);
        }

        .alert-box {
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .btn-gold {
            background: var(--gold-color);
            color: #000;
            border: none;
            font-weight: bold;
            min-height: 44px;
            padding: 0.5rem 1.5rem;
            touch-action: manipulation;
        }

        .btn-gold:hover {
            background: var(--gold-dark);
            color: #000;
        }

        /* Touch-friendly buttons */
        button,
        .btn,
        a.btn {
            min-height: 44px;
            min-width: 44px;
            touch-action: manipulation;
        }

        /* Responsive tables */
        .table-responsive {
            -webkit-overflow-scrolling: touch;
        }

        .mobile-card-view {
            display: none;
        }

        .mobile-card {
            background: var(--bs-card-bg);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border-left: 4px solid var(--gold-color);
        }

        .mobile-card .card-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--bs-border-color);
        }

        .mobile-card .card-row:last-child {
            border-bottom: none;
        }

        .mobile-card .card-label {
            font-weight: 600;
            color: var(--bs-secondary);
            font-size: 0.875rem;
        }

        .mobile-card .card-value {
            text-align: right;
            font-weight: 500;
        }

        .mobile-card .card-actions {
            margin-top: 0.75rem;
            display: flex;
            gap: 0.5rem;
        }

        .mobile-card .card-actions .btn {
            flex: 1;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.show,
            .sidebar:not(.hidden) {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 1rem;
            }

            .main-content.sidebar-hidden {
                margin-left: 0;
            }

            .topbar {
                padding: 0.75rem 1rem;
                margin: -1rem -1rem 1rem -1rem;
            }

            #sidebarToggle {
                display: block !important;
                min-width: 44px;
                min-height: 44px;
                font-size: 1.25rem;
                padding: 0.5rem;
            }

            .user-info {
                gap: 0.5rem;
            }

            .user-info span {
                display: none;
            }

            .gold-card {
                padding: 1rem;
                margin-bottom: 1rem;
            }

            .gold-card h2 {
                font-size: 1.5rem;
            }

            .stat-card {
                padding: 1rem;
                margin-bottom: 1rem;
            }

            .card {
                margin-bottom: 1rem;
            }

            .card-body {
                padding: 1rem;
            }

            /* Hide desktop table, show mobile cards */
            .table-responsive {
                display: none;
            }

            .mobile-card-view {
                display: block;
            }

            /* Form improvements */
            .form-control,
            .form-select {
                font-size: 16px;
                /* Prevents zoom on iOS */
                padding: 0.75rem;
                min-height: 44px;
            }

            /* Better spacing */
            .row {
                margin-left: -0.5rem;
                margin-right: -0.5rem;
            }

            .row>* {
                padding-left: 0.5rem;
                padding-right: 0.5rem;
            }

            /* Chart container */
            .chart-container {
                height: 250px !important;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 0.75rem;
            }

            .topbar {
                padding: 0.5rem 0.75rem;
                margin: -0.75rem -0.75rem 0.75rem -0.75rem;
            }

            .gold-card h2 {
                font-size: 1.25rem;
            }

            .gold-card h5 {
                font-size: 1rem;
            }

            .stat-card h3 {
                font-size: 1.25rem;
            }

            .btn {
                padding: 0.5rem 1rem;
                font-size: 0.875rem;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar Overlay (Mobile) -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-brand">
            <div class="d-flex justify-content-between align-items-center">
                <img src="<?php echo BASE_URL; ?>image/NUGold.png" alt="NUGold">
                <button type="button" class="btn btn-link text-white d-md-none" id="sidebarClose">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="<?php echo BASE_URL; ?>index.php?action=dashboard" class="<?php echo $action === 'dashboard' ? 'active' : ''; ?>"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php?action=tambah_emas" class="<?php echo $action === 'tambah_emas' ? 'active' : ''; ?>"><i class="bi bi-plus-circle"></i> Tambah Emas</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php?action=riwayat_harga" class="<?php echo $action === 'riwayat_harga' ? 'active' : ''; ?>"><i class="bi bi-graph-up"></i> Riwayat Harga</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php?action=pengaturan_alert" class="<?php echo $action === 'pengaturan_alert' ? 'active' : ''; ?>"><i class="bi bi-bell"></i> Pengaturan Alert</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php?action=profil" class="<?php echo $action === 'profil' ? 'active' : ''; ?>"><i class="bi bi-person"></i> Profil</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php?action=logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Topbar -->
        <div class="topbar">
            <div>
                <button class="btn btn-sm btn-outline-secondary" id="sidebarToggle" title="Toggle Sidebar">
                    <i class="bi bi-list"></i>
                </button>
            </div>
            <div class="user-info">
                <button class="btn btn-sm btn-outline-secondary" id="darkModeToggle" title="Toggle Dark Mode">
                    <i class="bi bi-<?php echo $isDarkMode ? 'sun' : 'moon'; ?>"></i>
                </button>
                <span><?php echo htmlspecialchars($userName); ?></span>
                <?php if ($userPhoto): ?>
                    <img src="<?php echo htmlspecialchars($userPhoto); ?>" alt="User" class="user-avatar">
                <?php endif; ?>
            </div>
        </div>

        <!-- Page Content -->
        <?php echo $content ?? ''; ?>
    </div>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Dark Mode Toggle
        document.getElementById('darkModeToggle')?.addEventListener('click', function() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-bs-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

            html.setAttribute('data-bs-theme', newTheme);
            document.cookie = 'dark_mode=' + (newTheme === 'dark' ? '1' : '0') + '; path=/; max-age=31536000';

            const icon = this.querySelector('i');
            icon.className = 'bi bi-' + (newTheme === 'dark' ? 'sun' : 'moon');
        });

        // Sidebar Toggle - Initialize after DOM is ready
        (function() {
            let sidebar, mainContent, sidebarToggle, sidebarOverlay, sidebarClose;

            function initSidebar() {
                sidebar = document.querySelector('.sidebar');
                mainContent = document.querySelector('.main-content');
                sidebarToggle = document.getElementById('sidebarToggle');
                sidebarOverlay = document.getElementById('sidebarOverlay');
                sidebarClose = document.getElementById('sidebarClose');

                if (!sidebar) {
                    console.error('Sidebar element not found');
                    return;
                }

                console.log('Sidebar initialized', {
                    sidebar: !!sidebar,
                    overlay: !!sidebarOverlay,
                    toggle: !!sidebarToggle,
                    close: !!sidebarClose
                });

                setupSidebarEvents();
            }

            function isMobile() {
                return window.innerWidth <= 768;
            }

            function toggleSidebarMobile() {
                if (!sidebar) return;

                const isShowing = sidebar.classList.toggle('show');
                if (sidebarOverlay) {
                    if (isShowing) {
                        sidebarOverlay.classList.add('show');
                        console.log('Sidebar opened');
                    } else {
                        sidebarOverlay.classList.remove('show');
                        console.log('Sidebar closed');
                    }
                }
            }

            function closeSidebarMobile() {
                console.log('closeSidebarMobile called');
                if (sidebar) {
                    sidebar.classList.remove('show');
                }
                if (sidebarOverlay) {
                    sidebarOverlay.classList.remove('show');
                }
                console.log('Sidebar should be closed now');
            }

            function updateToggleIcon(hidden) {
                if (sidebarToggle) {
                    const icon = sidebarToggle.querySelector('i');
                    if (icon) {
                        if (isMobile()) {
                            icon.className = 'bi bi-list';
                        } else {
                            icon.className = hidden ? 'bi bi-chevron-right' : 'bi bi-chevron-left';
                        }
                    }
                }
            }

            function setupSidebarEvents() {
                // Close sidebar when clicking overlay
                if (sidebarOverlay) {
                    sidebarOverlay.addEventListener('click', function(e) {
                        console.log('Overlay clicked', e.target, sidebarOverlay);
                        if (e.target === sidebarOverlay) {
                            e.preventDefault();
                            e.stopPropagation();
                            closeSidebarMobile();
                        }
                    });

                    sidebarOverlay.addEventListener('touchstart', function(e) {
                        console.log('Overlay touched', e.target);
                        if (e.target === sidebarOverlay) {
                            e.preventDefault();
                            e.stopPropagation();
                            closeSidebarMobile();
                        }
                    }, {
                        passive: false
                    });
                } else {
                    console.error('Sidebar overlay not found');
                }

                // Close sidebar button
                if (sidebarClose) {
                    sidebarClose.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('Close button clicked');
                        closeSidebarMobile();
                    });
                } else {
                    console.warn('Sidebar close button not found');
                }

                // Sidebar toggle button - SINGLE EVENT LISTENER
                if (sidebarToggle) {
                    sidebarToggle.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('Toggle button clicked, isMobile:', isMobile());

                        if (isMobile()) {
                            toggleSidebarMobile();
                        } else {
                            const isHidden = sidebar.classList.toggle('hidden');
                            if (mainContent) {
                                mainContent.classList.toggle('sidebar-hidden', isHidden);
                            }
                            localStorage.setItem('sidebarHidden', isHidden);
                            updateToggleIcon(isHidden);
                        }
                    });
                } else {
                    console.error('Sidebar toggle button not found');
                }

                // Load sidebar state from localStorage (only for desktop)
                if (!isMobile()) {
                    const sidebarHidden = localStorage.getItem('sidebarHidden') === 'true';
                    if (sidebarHidden && sidebar) {
                        sidebar.classList.add('hidden');
                        if (mainContent) {
                            mainContent.classList.add('sidebar-hidden');
                        }
                        updateToggleIcon(true);
                    }
                }

                // Close sidebar when clicking menu item (mobile)
                if (isMobile()) {
                    document.querySelectorAll('.sidebar-menu a').forEach(link => {
                        link.addEventListener('click', function() {
                            setTimeout(closeSidebarMobile, 100);
                        });
                    });
                }
            }

            // Initialize when DOM is ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initSidebar);
            } else {
                initSidebar();
            }
        })();

        // Swipe gesture for sidebar (mobile) - moved inside IIFE
        (function() {
            let touchStartX = 0;
            let touchEndX = 0;
            let sidebarRef = null;

            function isMobile() {
                return window.innerWidth <= 768;
            }

            function handleSwipe() {
                if (!sidebarRef) return;

                const swipeThreshold = 50;
                const swipeDistance = touchEndX - touchStartX;

                // Swipe right to open (from left edge)
                if (touchStartX < 20 && swipeDistance > swipeThreshold && !sidebarRef.classList.contains('show')) {
                    sidebarRef.classList.add('show');
                    const overlay = document.getElementById('sidebarOverlay');
                    if (overlay) overlay.classList.add('show');
                }
                // Swipe left to close
                else if (swipeDistance < -swipeThreshold && sidebarRef.classList.contains('show')) {
                    sidebarRef.classList.remove('show');
                    const overlay = document.getElementById('sidebarOverlay');
                    if (overlay) overlay.classList.remove('show');
                }
            }

            // Wait for sidebar to be initialized
            setTimeout(function() {
                sidebarRef = document.querySelector('.sidebar');
            }, 100);

            document.addEventListener('touchstart', function(e) {
                if (isMobile()) {
                    touchStartX = e.changedTouches[0].screenX;
                }
            }, {
                passive: true
            });

            document.addEventListener('touchend', function(e) {
                if (isMobile()) {
                    touchEndX = e.changedTouches[0].screenX;
                    handleSwipe();
                }
            }, {
                passive: true
            });
        })();
    </script>
</body>

</html>